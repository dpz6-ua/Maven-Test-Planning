package ppss.practica3;

public class FicheroException extends Exception {
    public FicheroException() {
    }

    public FicheroException(String message) {
        super(message);
    }
}
