package ppss.practica3;
//David
public class ButacasException extends Exception {

    public ButacasException(String mensaje) {
        super(mensaje);
    }
}
