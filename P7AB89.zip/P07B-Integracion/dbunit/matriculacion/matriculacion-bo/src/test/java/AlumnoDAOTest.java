import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class AlumnoDAOTest {
    @Test
    public void A1(){
        assertTrue(true);
    }

    @Test
    public void A2(){
        assertTrue(true);
    }

    @Test
    public void A3(){
        assertTrue(true);
    }
}
