package ppss.P05;

public class ServicioSTUB implements IService{
    @Override
    public float consultaPrecio(TipoCoche tipo) {
        return 10;
    }
}
