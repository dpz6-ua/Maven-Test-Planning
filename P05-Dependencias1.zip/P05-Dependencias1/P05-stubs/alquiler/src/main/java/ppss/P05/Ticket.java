package ppss.P05;

public class Ticket {
    private float precio_final;
//getters y setters
    public void setPrecio_final(float precio_final) {
        this.precio_final = precio_final;
    }

    public float getPrecio_final() {
        return precio_final;
    }
}
