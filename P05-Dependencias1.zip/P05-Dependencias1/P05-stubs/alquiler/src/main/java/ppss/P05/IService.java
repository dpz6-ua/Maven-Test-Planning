package ppss.P05;

public interface IService {
    float consultaPrecio(TipoCoche tipo);
}
