package ppss.P05;

public class CalendarioException extends Exception {

}
