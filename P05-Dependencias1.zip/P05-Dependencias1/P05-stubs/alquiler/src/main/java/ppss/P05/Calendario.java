package ppss.P05;

import java.time.LocalDate;

public class Calendario {
    public boolean es_festivo(LocalDate otroDia) throws CalendarioException{
        throw new UnsupportedOperationException ("Not yet implemented");
    }
}
