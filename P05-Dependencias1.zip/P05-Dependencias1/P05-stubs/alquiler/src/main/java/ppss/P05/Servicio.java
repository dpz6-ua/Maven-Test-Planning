package ppss.P05;

public class Servicio implements IService{
    @Override
    public float consultaPrecio(TipoCoche tipo) {
        throw new UnsupportedOperationException ("Not yet implemented");
    }
}
