package ppss.P05;

public enum TipoCoche {TURISMO,DEPORTIVO,CARAVANA};
