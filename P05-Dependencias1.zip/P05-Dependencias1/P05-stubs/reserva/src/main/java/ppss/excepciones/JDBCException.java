package ppss.excepciones;

public class JDBCException extends Exception {

}
