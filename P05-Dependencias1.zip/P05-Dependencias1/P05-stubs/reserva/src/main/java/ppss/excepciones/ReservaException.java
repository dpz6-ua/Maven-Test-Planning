package ppss.excepciones;

public class ReservaException extends Exception {
    public ReservaException(String message) { super(message);}
}
