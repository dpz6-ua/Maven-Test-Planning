package ppss.excepciones;

public class SocioInvalidoException extends RuntimeException {

}
