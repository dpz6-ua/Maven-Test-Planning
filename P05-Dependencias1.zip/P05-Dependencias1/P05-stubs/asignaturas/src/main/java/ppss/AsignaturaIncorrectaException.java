package ppss;

public class AsignaturaIncorrectaException extends Exception {
    public AsignaturaIncorrectaException() {
        super();
    }
}
