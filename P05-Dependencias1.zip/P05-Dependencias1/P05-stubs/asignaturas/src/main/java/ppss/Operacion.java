package ppss;

import java.util.Arrays;
import java.util.List;

public class Operacion {

    public void compruebaMatricula(String dni, String asignatura) throws AsignaturaIncorrectaException, AsignaturaCursadaException {

    }
}
