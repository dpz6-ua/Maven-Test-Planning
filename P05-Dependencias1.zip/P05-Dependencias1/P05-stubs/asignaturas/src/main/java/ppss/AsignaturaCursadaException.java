package ppss;

public class AsignaturaCursadaException extends Exception {
    public AsignaturaCursadaException() {
        super();
    }
}
