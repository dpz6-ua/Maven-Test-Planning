package ppss.P05.llamadas;

public class Calendario {
    public int getHoraActual() {
        throw new UnsupportedOperationException ("Not yet implemented");
    }
}
