package ppss.exceptions;

public class FicheroException extends Exception {
    public FicheroException(String mensaje) {
        super(mensaje);
    }
}
