package ppss;

public class FactoriaBOs {
    public IOperacionBO getOperacionBO(){
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
