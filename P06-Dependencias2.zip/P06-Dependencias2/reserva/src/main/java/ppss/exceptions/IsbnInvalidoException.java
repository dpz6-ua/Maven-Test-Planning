package ppss.exceptions;

public class IsbnInvalidoException extends Exception {
}
