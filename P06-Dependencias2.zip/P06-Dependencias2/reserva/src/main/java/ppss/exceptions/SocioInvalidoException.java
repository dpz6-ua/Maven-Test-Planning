package ppss.exceptions;

public class SocioInvalidoException extends Exception {

}
