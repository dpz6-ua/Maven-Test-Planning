package ppss.exceptions;

public class ReservaException extends Exception {
    public ReservaException(String message) {
        super(message);
    }
}
