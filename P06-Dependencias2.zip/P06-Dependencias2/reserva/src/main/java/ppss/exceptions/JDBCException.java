package ppss.exceptions;

public class JDBCException extends Exception {

}
