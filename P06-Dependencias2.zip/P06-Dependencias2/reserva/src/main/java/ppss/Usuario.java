package ppss;

public enum Usuario {
    BIBLIOTECARIO, PERRO
}
