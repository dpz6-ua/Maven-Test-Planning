package ppss;
import ppss.exceptions.ClienteWebServiceException;

public class ClienteWebService {
    public String obtenerPremio() throws ClienteWebServiceException {
        throw new UnsupportedOperationException ("Not yet implemented");
    }
}
