package ppss.exceptions;

public class ClienteWebServiceException extends Exception {

}
